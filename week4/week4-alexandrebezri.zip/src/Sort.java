interface Sort {
    int[] sort(int[] in);
}
